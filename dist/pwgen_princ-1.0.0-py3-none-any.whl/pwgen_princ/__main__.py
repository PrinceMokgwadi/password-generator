from pwgen_princ.pwgen import main

if __name__ == "__main__":
    main()

