# Password Generator

This project generates random secure passwords using Python. Safe and beginner-friendly cybersecurity project.
